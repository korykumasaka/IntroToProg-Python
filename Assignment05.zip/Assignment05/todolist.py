'''
Title: Task List
Dev: K Shaffer
Date: 11/17/18
Change Log: (Who, When, What)
    K Shaffer, 11/17/18, Generated Initial Script
'''
D = {}
#Open ToDo.txt
with open("ToDo.txt", "r") as ToDo:
#Read each row of data from ToDo.txt and store in a dictionary
    for row in ToDo:
        line = row.split(",")
        item, priority = line[0], line[1]
        D[item] = priority.strip("\n")

#Add the dictonary as a row in a list
list = []
for item in D:
    priority = D[item]
    list.append(item + " : " + priority)

#Print list
print ("Currently your Todo list contains the following:\n", list)

#loop through user inputs and perform requested operation
while(True):

    # Print list of available user operations and ask for input
    print("""\n***Menu of Operations***\n
        1) Show current data\n
        2) Add a new item\n
        3) Remove an existing item\n
        4) Save data to file\n
        5) Exit program\n   
            """)

    Selection = input("What operation would you like to perform?\n")

    if Selection == "1":
        print(list)

    elif Selection == "2":
        newitem = input("What item would you like to add?")
        priority = input("What is the priority of " + newitem + "?")
        list.append(newitem + " : " + priority)

    elif Selection == "3":
        print(list)
        removeitem = input("What item would you like to remove?")
        list.remove(removeitem)

    elif Selection == "4":
        filename = input("What file would you like to save the data to?")
        with open(filename+".txt", "w") as newfile:
            for item in list:
                newfile.write("%s\n" % item)

    elif Selection == "5":
        break

    else: print("that is not a valid operation")

#Write data to ToDo.txt
with open("ToDo.txt", "w") as ToDo:
    for item in list:
        ToDo.write("%s\n" % item)
#Close ToDo.txt
ToDo.close()