'''
Title: Task List
Dev: K Shaffer
Date: 11/25/18
Change Log: (Who, When, What)
    K Shaffer, 11/17/18, Generated Initial Script
    K Shaffer, 11/25/18, Modified Code to Utilize Functions and a Class
'''
###-- Processing --###
class MyFunctions():
    def ReadData():
        list = []
        D = {}
        with open("ToDo.txt", "r") as ToDo:
            for row in ToDo:
                line = row.split(",")
                item, priority = line[0], line[1]
                D[item] = priority.strip("\n")
            for i in D:
                priority = D[i]
                list.append(i + " : " + priority)
            return list

    def WriteData(list):
        with open("ToDo.txt", "w") as ToDo:
            for item in list:
                ToDo.write("%s\n" % item)
        ToDo.close()
        return list

    def MenuOuput():
        print("""\n***Menu of Operations***\n
            1) Show current data\n
            2) Add a new item\n
            3) Remove an existing item\n
            4) Save data to file\n
            5) Exit program\n   
                """)

    def AddItem(list):
        newitem = input("What item would you like to add?")
        priority = input("What is the priority of " + newitem + "?")
        list.append(newitem + " : " + priority)
        return list

    def RemoveItem(list):
        removeitem = input("What item would you like to remove?")
        list.remove(removeitem)
        return list

    def SaveData(list):
        filename = input("What file would you like to save the data to?")
        with open(filename + ".txt", "w") as newfile:
            for item in list:
                newfile.write("%s\n" % item)

###-- Input/Output --###

#Read Data From ToDo.txt
List = MyFunctions.ReadData()

#Print List
print ("Currently your Todo list contains the following:\n", List)

#loop through user inputs and perform requested operation
while(True):
    # Print list of available user operations and ask for input
    MyFunctions.MenuOuput()
    Selection = input("What operation would you like to perform?\n")

    if Selection == "1":
        print(List)

    elif Selection == "2":
        List = MyFunctions.AddItem(List)

    elif Selection == "3":
        print(List)
        List = MyFunctions.RemoveItem(List)

    elif Selection == "4":
        MyFunctions.SaveData(List)

    elif Selection == "5":
        break
    else: print("that is not a valid operation")

#Write data to ToDo.txt
MyFunctions.WriteData(List)




