'''
Title: Simple Exception Code
Dev: K Shaffer
Date: 12/3/18
Change Log: (Who, When, What)
    K Shaffer, 12/3/18, Generated Initial Script
'''


try:
    # Print out purpose of the script and tell them how to end the script
    print ("This tool will help you calculate grade points for a single class. /n Enter 'exit' when you are done!")

    GP = None #Create variable to hold grade points

    while(True):

        UserInput = input("Enter grade points the letter grade is worth (ie B = 3.0): ") #User enters letter grade points
        UserInput2 = input("how many credits is this class worth?") #User enters credits
        if UserInput.lower() == "exit": break #Break the loop when user types exit

        else:
            GP = float(UserInput)*float(UserInput2) #Multiply user inputs
            print ("You earned " + str(GP) + " grade points for this class")  # Print earned grade points

except Exception as e:
    print("There seems to be an issue...." + e ) #Report if an error occured
finally:
    print ("GPA program has ended") #Inform user the program has ended