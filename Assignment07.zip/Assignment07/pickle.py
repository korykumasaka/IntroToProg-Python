'''
Title: Simple Pickle Code
Dev: K Shaffer
Date: 12/3/18
Change Log: (Who, When, What)
    K Shaffer, 12/3/18, Generated Initial Script
'''

import pickle #import pickle

print("There is a student named Kyle") #report students name to be converted to binary

Name = "Kyle" #assign 'Kyle' to name variable
list = open("C:\\_PythonClass\Assignment07\list.dat", "ab") #open and append binary file
pickle.dump(Name, list) #add name to binary file
list.close() #close binary file

list = open("C:\\_PythonClass\Assignment07\list.dat", "rb") #read binary file
SList = pickle.load(list) #assign name to SList veriable
list.close() #close binary file

print("The Students name in binary is" + SList)